<?php

/*
 * Require ini file with settings
 */
require_once __DIR__ . '/core/ini.php';

$user = new User();
$lead = new Lead();
$note = new Note();




if($user->isLoggedIn()){


if ($id = Input::get('id')){

$employee = new User($id);

	if($employee->find($id)){
	
	if($user->hasPermission('superAdmin')){

	
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>CRM</title>

        <link href="view/css/reset.css" rel="stylesheet">
        <link href="view/css/style.css" rel="stylesheet">

        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">

        <link href="view/css/remodal.css" rel="stylesheet">
        <link href="view/css/remodal-default-theme.css" rel="stylesheet">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="view/js/remodal.js"></script>



    </head>
    <body>

    <header id="header">
        <button id="open-nav" onclick="w3_open()">&#9776;</button>
        <li>
            <a href="index.php" class="tooltip">
                <i class="fas fa-home"></i>
                <span class="tooltiptext">Dashboard</span>
            </a>
            <a href="calendar.php" class="tooltip">
                <i class="far fa-calendar-alt"></i>
                <span class="tooltiptext">Calendar</span>
            </a>
            <?php

            if ($user->hasPermission('superAdmin')){
                echo '
              <a href="employees.php" class="link-selected tooltip">
<i class="fas fa-users"></i>
                <span class="tooltiptext">Employees</span>
            </a>

            
            ';


            } ?>            <a href="leads.php" class="tooltip">
                <i class="far fa-dot-circle"></i>
                <span class="tooltiptext">Leads</span>
            </a>
            <a href="contacts.php" class="tooltip">
                <i class="far fa-address-book"></i>
                <span class="tooltiptext">Contacts</span>
            </a>
            <a href="customers.php" class="tooltip">
                <i class="fas fa-dollar-sign"></i>
                <span class="tooltiptext">Customers</span>
            </a>
            <a href="inventory.php" class="tooltip">
                <i class="fas fa-boxes"></i>
                <span class="tooltiptext">Inventory</span>
            </a>
        </li>
        <form class="search" action="#" method="get">
            <input id="txt1" class="search-input" type="text" name="search" placeholder="Search" onkeyup="showHint(this.value)">
            <div id="txtHint" class="search-box">

            </div>

            <script>
                function showHint(str) {
                    var xhttp;
                    if (str.length == 0) {
                        document.getElementById("txtHint").innerHTML = "";
                        return;
                    }
                    xhttp = new XMLHttpRequest();
                    xhttp.onreadystatechange = function() {
                        if (this.readyState == 4 && this.status == 200) {
                            document.getElementById("txtHint").innerHTML = this.responseText;
                        }
                    };
                    xhttp.open("GET", "search.php?q="+str, true);
                    xhttp.send();
                }
            </script>
        </form>
        <div class="tooltip msg-open">
            <i class="fas fa-envelope"></i>
            <span class="tooltiptext">Inbox</span>
        </div>
        <div class="tooltip ntf-open" id="ntf">
            <i class="fas fa-bell">
                <?php

                $ntf = new Notification();

                $i = 0;

                foreach($ntf->getNotifications() as $ntf){
                    if($ntf->userID == $user->data()->id && $ntf->seen == 0){
                        $i++;
                    }
                }

                if($i != 0){
                    echo '<span class="ntf-count">'.$i.'</span>';
                }

                ?>





            </i>
            <span class="tooltiptext">Notifications</span>
        </div>
        <div class="tooltip add-open">
            <i class="fas fa-plus-circle"></i>
            <span class="tooltiptext">Add</span>
        </div>
        <div class="profile">
            <div class="profile-name drop-menu" onclick="myFunction()"><?php echo escape($user->data()->firstName).' '.escape($user->data()->lastName)?></div>
            <div class="profile-image drop-menu" onclick="myFunction()" style="background: url('<?php echo 'view/img/profile/'.escape($user->data()->img) ?>') no-repeat center; background-size: 5vh;"></div>
        </div>
    </header>

    <div class="dropdown">
        <div id="myDropdown" class="dropdown-content">
            <a href="#" data-remodal-target="profile" class="profile-ico">Profile</a>
            <a href="#" class="settings-ico">Settings<span class="notification-sign-yellow">!</span></a>
            <a href="logout.php" class="logout-ico">Log out</a>
        </div>
    </div>

    <aside id="index-sidebar">
        <div class="sidebar-header">
            <div id="logo">Eduscape CRM</div>
            <button id="close-nav" onclick="w3_close()">&times;</button>
        </div>

        <nav class="sidebar-nav">
            <button class="sidebar-dropdown-btn">menu
                <span class="sidebar-dropdown-icon">&#9660</span>
            </button>
            <div class="sidebar-dropdown-container">
                <a href="#">submenu</a>
                <a href="#">submenu</a>
            </div>
            <a href="#">menu</a>
            <a href="#">menu</a>
            <button class="sidebar-dropdown-btn">menu
                <span class="sidebar-dropdown-icon">&#9660</span>
            </button>
            <div class="sidebar-dropdown-container">
                <a href="#">submenu</a>
                <a href="#">submenu</a>
                <a href="#">submenu</a>
            </div>
            <a href="#">menu</a>
        </nav>

    </aside>

   <?php  include_once __DIR__ . '/include/ntf.php';   ?>

    <aside id="msg-sidebar">
        <div class="msg-sidebar-header">
            <div class="msg-close">&times;</div>
            <h2>Massages</h2>
        </div>
        <div class="msg-sidebar-content">

        </div>
    </aside>

    <?php

include_once __DIR__ . '/include/addSidebar.php';

?>

    <section id="content">
    
    <div  class="profile-page" >
    

     <div class="profile-page-info">
     <div class="profile-page-header">
         <div class="profile-page-picture" style="background: url('/view/img/profile/<?php echo $employee->data()->img ?>') no-repeat center; background-size: 10vh;"></div>

         <div class="profile-page-name"><?php echo $employee->data()->firstName .' '. $employee->data()->lastName ?></div>
         <div class="profile-page-occupation"><?php echo $employee->data()->role ?></div>

         <div class="profile-page-button">
             <a href="#"><i class="fab fa-facebook-square"></i></a>
             <a href="#"><i class="fab fa-twitter-square"></i></a>
             <a href="#"><i class="fab fa-linkedin"></i></a>
            
               
         </div>
</div>


         <div class="profile-page-data"><i class="fas fa-envelope"></i><?php echo $employee->data()->email ?></div>
         <div class="profile-page-data"><i class="fas fa-phone"></i><?php echo $employee->data()->phone ?></div>
         <div class="profile-page-data"><i class="fas fa-road"></i><?php echo $employee->data()->street ?></div>
         <div class="profile-page-data"><i class="fas fa-university"></i><?php echo $employee->data()->city ?></div>
         <div class="profile-page-data"><i class="fas fa-flag"></i><?php echo $employee->data()->state ?></div>
         <div class="profile-page-data"><i class="fas fa-globe"></i><?php echo $employee->data()->country ?></div>
         <div class="profile-page-data"><i class="fas fa-file-archive"></i><?php echo $employee->data()->zip ?></div>
         <div class="profile-page-data"><i class="fas fa-handshake"></i><?php echo $employee->data()->joined ?></div>
         <div class="profile-page-data"><i class="fas fa-user-friends"></i></div>
         <div class="profile-page-data"><i class="fas fa-user-alt"></i></div>
         <div class="profile-page-data"><i class="fas fa-comment-alt"></i></div>

     </div>
     
     <div class="profile-page-notes">
     
     
     <?php 
     
   
     
     if($user->hasPermission('superAdmin')){
     		foreach ($note->getNotes() as $note){
     		
     			if($note->section == "employee" && $note->contactsID == $id){
     				 echo "<div class='profile-page-note'>
     	       
     		<div class='profile-page-note-header'>
     			<label>". $note->title."</label>
     		</div>
     		<div class='profile-page-note-text'>". $note->content."</div>
     		 <div class='profile-page-note-delete-bar'>
     		 <div><i class='fas fa-edit'></i></div>
     		 <a href='#deleteNote-". $note->id ."'><i class='fas fa-trash'></i></a>
     		 <div class='profile-page-note-delete-bar-date'>". $note->createdOn."</div>
     		 </div>
     	</div>
     		
     		
     		<!-- REmodal delete note -->
    
    <div class='remodal' data-remodal-id='deleteNote-". $note->id ."'>
        <form action='deleteNote.php' method='post' class='contact-delete-contact'>
        	<h3>Are you sure you want delete this note?</h3>
        	<input type='hidden' name='case' value='employee'>
        	<input type='hidden' name='id' value='". $id ."'>
        	<input type='hidden' name='noteID' value='". $note->id ."'>
                <button type='submit' class='button'><i class='fas fa-trash'></i>Delete</button>
                <button type='button' data-remodal-action='cancel' class='button'><i class='fas fa-ban'></i>Cancel</button>
        </form>
    </div>
     		
     		
     		
     		";
     			
     			}
     		}
     		
     		
     		
     		
     
     echo "
     <form class='profile-page-note-form' method='post' action='addNote.php'>
              <h4 class='profile-page-note-form-header'>New note</h4>
              	<input class='profile-page-note-form-add-title' type='text' name='contactNoteTitle' placeholder='Note title'>
              	<textarea class='profile-page-note-form-add-content' type='text' name='contactNoteContent' placeholder='Note content'></textarea>
              	
              	<input type='hidden' name='case' value='employee'>
        	<input type='hidden' name='id' value='". $id ."'>
        	<input type='hidden' name='contactNoteProtected' value='protected'>
              	
              <button  class='profile-page-note-form-button' type='submit'><i class='fas fa-plus'></i> Add</button>
              </form>";
     
     }
     ?>
     	
       
              
     	     
     	
     	</div>
     
     










    

</div> 
        
    </section>

    <footer id="footer">

    </footer>


    <div class="flash-msg <?php if(Session::exists('home')){ echo 'show-msg';} ?>">
        <?php

        if(Session::exists('home')) {

            echo Session::flash('home');
        }
        ?>

    </div>
    
    



    <!-- Remodals -->

   <?php

    	include_once __DIR__ . '/include/newEmployee.php';

	include_once __DIR__ . '/include/newLead.php';
	
	include_once __DIR__ . '/include/newCustomer.php';
	
	include_once __DIR__ . '/include/newContact.php';

include_once __DIR__ . '/include/newEvent.php';

   include_once __DIR__ . '/include/newItem.php';
	
	include_once __DIR__ . '/include/infoProfile.php';
   
    ?>

    </body>
    </html>

    

    <?php
    
    include_once __DIR__ . '/include/scripts.php';

}else{

    Redirect::to('employees.php');

}}else{
	Redirect::to('employees.php');
}

}else{
	Redirect::to('index.php');
}

}else{
	Redirect::to('index.php');
}