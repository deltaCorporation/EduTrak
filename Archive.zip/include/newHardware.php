<form action="addHardware.php" method="post" id="add-hardware-window" class="add-window">
    <div class="add-window-header event-bg-color">
        <div class="add-window-header-icon hardware-icon"></div>
        <div class="add-window-header-title">Create new hardware item</div>
        <button type="button" class="add-window-close window-close"></button>
    </div>
</form>